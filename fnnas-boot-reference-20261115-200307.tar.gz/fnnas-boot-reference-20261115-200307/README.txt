Source: FNNAS v389 Panther X2 64GB TF card
Source partition: /dev/mmcblk1p1
Source UUID: df2bcae1-5040-4851-b3cc-5332a0914d10
Extraction host: 9.2
Extraction mode: source partition mounted read-only during extraction.

Important provenance note:
The partition was automatically mounted read-write by the host immediately
after insertion, and the kernel reported EXT4 journal recovery complete.
It was subsequently remounted read-only before this extraction.
No filesystem repair was performed.
